var express = require('express');
var router = express.Router();
const connection = require('../util/connection');

router.post('/reg-form-check',(req,res,next) =>{
    const fname = req.body.fname ; 
    const lname = req.body.lname;
    const email = req.body.email;
    const password = req.body.password;
    const gender = req.body.gender;
    const income = req.body.income;
    const value = req.body.value;
    const age = req.body.age;
    const bio = req.body.bio
    console.log(fname,lname,email,password,gender,income,value,age,bio);

    //insert into db:
    try {
    connection.query(`INSERT INTO studentInfo VALUES ('${fname}', '${lname}', '${email}', '${password}','${gender}','${income}','${value}','${age}','${bio}')`,(error)=>{
        if(error){
            return res.send(error)
        }

       res.send('<h1>Data inserted successfully!</h1>')
    });

    
    //res.render('reg-form');
}catch(e){
        console.log(e);
}
})

module.exports = router;
var express = require('express');
const connection = require('../util/connection');
var router = express.Router();

/* GET home page. */
router.post('/checkValidate', function(req, res, next) {
  const email = req.body.email;
  const pass = req.body.pass;
  console.log(email,pass);
    try {
  connection.query((`select * from studentInfo where email = '${email}'`),(error,results,fields)=>{
      if(results[0].pass === pass){
          console.log('login successful!');
          //res.send('<h1> Welcome </h1>')
          res.render('/');
      }else {
          res.send('check username / password!')
          console.log(error);
      }
  })
    }catch(e){
        console.log('error!');
    }
  //res.render('index', { title: 'Express' });
});

module.exports = router;

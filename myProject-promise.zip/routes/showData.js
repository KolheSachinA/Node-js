var express = require('express');
var router = express.Router();
const verifyjwt = require('../util/verifyJwtToken');
const connection = require('../util/connection');
const exeQuery = require('../util/exeQuery').exeQuery;


/* GET home page. */
router.get('/showData', function (req, res, next) {
  console.log(req.cookies);
  verifyjwt.verifyJwtAuth(req.cookies.info.code).then((result) => {
    if (result === 'Verified Successfully') {
      console.log(result);
      const query = `select * from studentdata where email = '${req.cookies.info.email}'`;
      exeQuery(query).then((result) => {
        res.render('studentData', { result })
      }).catch((error) => {
        console.log(error)
        return
      })
    }
  }).catch((error) => {
    return console.log(error);
  })

});

module.exports = router;

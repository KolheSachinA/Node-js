
const connection = require('./connection');
const moment = require('moment');

const exeQuery = (query) => {
    return new Promise((resolve,reject) =>{
        connection.query(`insert into attendance values ('${email}','${time}',0,'${JSON.stringify(datesObj)}')`, (error, result) => {
            if (error) return console.log(error);

            console.log('result of attendance:', result);

          })
    })
}

exports.exeQuery = exeQuery;